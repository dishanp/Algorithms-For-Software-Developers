#include <iostream>
using namespace std;
int i=0;
class student
{
    float avg_marks;
    public:
    void get()
    {
        cout<<"Enter Avg Marks of student "<< ++i <<": ";
        cin>>avg_marks;
        cout<<endl;
    }
    void show()
    {
        cout<<"Avg Marks of student is "<<avg_marks;
        cout<<endl;
    }
    student operator +(student b)
    {
        student o;
        o.avg_marks=avg_marks+b.avg_marks;
        return o;
    }
};
int main()
{
   student s1,s2,s3;
   s1.get();
   s2.get();
   s3=s1.operator+(s2);
   s3.show();
   return 0;
}