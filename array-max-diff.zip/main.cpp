#include <iostream>
using namespace std;
int main()
{
cout<<"ENTER SIZE OF ARRAY== ";
int n;
cin>>n;
int a[n];
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    for(int i=0;i<n;i++)
    {
        cout<<" "<<a[i]<<" ";
    }
    int diff=0;
    int md=-32000;
 for(int i=0;i<n;i++)
 {
     for(int j=0;j<i;j++)
     {
         diff=a[i]-a[j];
         if(diff>md)
         {
             md=diff;
         }
     }
 }
 cout<<md;
}

