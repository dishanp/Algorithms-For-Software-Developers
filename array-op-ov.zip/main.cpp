// Q2 - Integer ARRAY INPUT AND OUTPUT
#include <iostream>
using namespace std;
class Arr
{
   int *a;
    public:
          Arr()
        {
            a=new int[5];
        }
       friend istream & operator >> (istream &temp,Arr &o);
       
       friend ostream & operator << (ostream &temp,Arr &o);
        
}; 
         istream & operator >> (istream &temp,Arr &o)
        {
            for(int i=0;i<5;i++)
            {
            cout<<"Enter Element "<<i+1<<":";
            temp>>o.a[i];
            }
        }
        ostream & operator << (ostream &temp,Arr &o)
        {
            for(int i=0;i<5;i++)
            {
            temp<<o.a[i]<<" ";
            }
        }
        
int main()
{
    Arr a1;
    cin>>a1;
    cout<<"The Array Is : ";
    cout<<a1;
    return 0;
}
