#include<stdio.h>
#include<stdlib.h>
int main()
{
    int *a;
    int n;
    printf("Enter the size of the array: ");
    scanf("%d",&n);
    a=(int *)malloc(n*sizeof(int));
    for(int i=0;i<n;i++)
    {
        printf("\n Enter element %d: ",i+1);
        scanf("%d",&a[i]);
    }
    printf("\nThe Array Is: \n");
    for(int i=0;i<n;i++)
    {
        printf("%d ",a[i]);
    }
}