import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int b=sc.nextInt();
	    int a=sc.nextInt();
	    String c=sc.next();
		BankAccount obj1=new BankAccount();
		BankAccount obj2=new BankAccount(a,b,c);
		obj1.dis();
		obj2.dis();
		obj2.with(200);
		obj1.dep(8999);
		obj1.com(obj1,obj2);
	}
}
class BankAccount
{
    int bal;
    String name;
    int acc_no;
    BankAccount()
    {
        bal=13332;
        name="raju";
        acc_no=283;
    }
    BankAccount(int b,int a,String n)
    {
        bal=b;
        acc_no=a;
        name=n;
    }
    void dis()
    {
       System.out.println(name);
       System.out.println(acc_no);
       System.out.println(bal);
    }
    void dep(int x)
    {
        bal+=x;
        System.out.println("Updated balance is "+bal);
    }
    void with(int y)
    {
        if(bal>=y)
        {
            bal-=y;
            System.out.println("Updated balance is "+bal);
        }
    }
    void com(BankAccount a,BankAccount b)
    {
        if(a.bal>b.bal)
        System.out.println(a.bal);
        else
        System.out.println(b.bal);
    }
}
