#include<iostream>
using namespace std;
#include<fstream>
#include<string.h>
#include<stdio.h>
int main()
{
    char ch[100];
    gets(ch);
    ofstream fout;
    fout.open("TEST.bin");
    fout.write((char*)&ch,sizeof(ch));
    fout.close();
    ifstream fin;
    fin.open("TEST.bin",ios::binary);
    fin.read((char*)&ch,sizeof(ch));
    puts(ch);
    for(int i=strlen(ch);i>=0;i--)
    cout<<ch[i];
    return 0;
}