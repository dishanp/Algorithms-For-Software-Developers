#include <stdio.h>
#include<stdlib.h>

struct tree
{
    int data;
    struct tree *left;
    struct tree *right;
};
int c;
struct tree *root=NULL;
void insert(struct tree *t,int key)
{
    struct tree *r=NULL;
    while(t)
    {
        r=t;
        if(key==t->data)
        return;
        if(key>t->data)
        t=t->right;
        else
        t=t->left;
    }
    struct tree *p=( struct tree *)malloc(sizeof( struct tree));
    p->data=key;
    p->left=p->right=NULL;
    if(p->data>r->data)
    r->right=p;
    else
    r->left=p;
}
void create(int n)
{
    int x;
    for(int i=0;i<n;i++)
    {
    printf("\nEnter Data of Node %d :  ",i+1);
    scanf("%d",&x);
    insert(root,x);
    }
    printf("\n");
        
}
void inorder(struct tree *t)
{
    if(t)
    {
        inorder(t->left);
        printf("%d ",t->data);
        inorder(t->right);
    }
}
int maxmin(struct tree *t)
{
    while(t->left)
    t=t->left;
    printf("\nMinimum Node Data in BST : %d",t->data);
    t=root;
    while(t->right)
    t=t->right;
    printf("\nMaximum Node Data in BST : %d",t->data);
}
int Kth_Largest(struct tree *t)
{
    int x;
    printf("\nEnter Value of K: ");
    scanf("%d",&x);
    for(int i=0;i<x;i++)
    t=t->right;
    printf("\nMaximum Node Data in BST : %d",t->data);
}
}
int count_range()
{
    int l,h;
    printf("\nEnter Lower Range Of Search:  ");
    scanf("%d",&l);
    printf("\nEnter Upper Range Of Search:  ");
    scanf("%d",&h);
    inorder2(root,l,h);
}
int inorder2(struct tree *t,int l,int h)
{
    if(t)
    {
        inorder2(t->left,l,h);
        if(t->data>=l&&t->data<=h)
        {
        c++;
        printf("%d ",t->data);
        }
        inorder2(t->right,l,h);
    }
}
int main()
{
    int n;
    root=( struct tree *)malloc(sizeof( struct tree ));
    printf("Enter Root Node Data :  ");
    scanf("%d",&root->data);
    root->left=root->right=NULL;
    printf("\nEnter No Of Nodes In BST:  ");
    scanf("%d",&n);
    create(n);
    inorder(root);
    printf("\n");
    maxmin(root);
    printf("\n");
    count_range(root);
    printf("\nNo of nodes in given range is: %d ",c);
    return 0;
}

