#include <stdio.h>
#include<stdlib.h>

struct queue 
{
    int size;
    int front;
    int rear;
    struct tree **data;
};
struct tree
{
    int data;
    struct tree *left;
    struct tree *right;
};
struct tree *root=NULL;
void createTree()
{
     struct tree *p,*t;
     int x;
     struct queue *q;
     createQueue(&q,50);
     root=(int *)malloc(sizeof(struct tree));
     printf("Enter data for node- ");
     scanf("%d",&x);
     root->data=x;
     root->left=root->right=NULL;
     enqueue(&q,root);
     while(isEmpty(q))
    {
         p=dequeue(&q);
         printf("Enter left child of %d",p->data);
         scanf("%d",&x);
         if(x!=-1)
         {
            t=(int *)malloc(sizeof(struct tree));
            t->left=t->right=NULL;
            p->left=t;
            enqueue(&q,t);
         }
         printf("Enter right child of %d",p->data);
         scanf("%d",&x);
         if(x!=-1)
         {
            t=(int *)malloc(sizeof(struct tree));
            t->left=t->right=NULL;
            p->right=t;
            enqueue(&q,t);
         }
    }
}
void createQueue(struct queue *q,int s)
{
    q->front=q->rear=0;
    q->size=s;
    q->data=(struct tree **)malloc(q->size*(sizeof(struct tree *)));
}
void enqueue(struct queue *q,struct tree *t)
{
    if((q->rear+1)%q->size==q->front)
    {
        printf("Overflow!!! \n");
    }
    else
    {   q->rear=(q->rear+1)%q->size;
        q->data[q->rear]=t;
    }
}
struct tree *dequeue(struct queue *q)
{
    struct tree *t=NULL;
    if(q->front==q->rear)
    printf("Underflow!!!\n");
    else
    {
        q->front=(q->front+1)%q->size;
        t= q->data[q->front];
    }
    return t;
}
int isEmpty(struct queue q)
{
    return q.front==q.rear ;
}
int main()
{
    createTree(root);
    preorder(root);
    return 0;
}
