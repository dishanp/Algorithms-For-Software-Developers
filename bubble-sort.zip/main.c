//bubble sort
#include<stdio.h>
#include<stdlib.h>
void display(int *a,int n)
{
    printf("\nThe Array Is: \n");
    for(int i=0;i<n;i++)
    {
        printf("%d ",a[i]);
    }
}
void bubble( int *a,int n)
{
int temp;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n-i-1;j++)
        {
            if(a[j]>a[j+1])
            {
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }
    }
}
int main()
{
    int *a;
    int n;
    printf("Enter the size of the array: ");
    scanf("%d",&n);
    a=(int *)malloc(n*sizeof(int));
    for(int i=0;i<n;i++)
    {
        printf("\n Enter element %d: ",i+1);
        scanf("%d",&a[i]);
    }
    display(a,n);
    bubble(a,n);
    display(a,n);
}

