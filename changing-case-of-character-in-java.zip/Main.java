public class Main
{
	public static void main(String[] args) {
	    char ch='A';
	    ch+=32;
	    System.out.println(ch);
	    ch='b';
	    ch-=32;
	    System.out.println(ch);
	}
}

