#include<iostream>
using namespace std;
#include<string.h>
#include<stdio.h>
int main()
{
    char name[20];
    cout<<"Enter the student's name: ";
    try
    {
        gets(name);
        if(strlen(name)>20)
        {
            throw(name);
        }
        else if(!(name[0]>=65&&name[0]<=90))
        {
            throw(name);
        }
        else
        {
            cout<<name<<" is perfectly valid! "<<endl;
        }
        
    }
    catch(char *c)
    {
        puts(c);
        cout<<" is an invalid name! ";
    }
    return 0;
}