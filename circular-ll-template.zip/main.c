#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
    struct node *prev;
};
void create(struct node **head,struct node **last,int n)
{
    int el;
    struct node *t=NULL;
    for(int i=0;i<n;i++)
    {
        t=(struct node *)malloc(sizeof(struct node));
        printf("\n Enter Data No %d:",i+1);
        scanf("%d",&t->data);
        t->next=NULL;
        t->prev=NULL;
        if(i==0)
        {
            *head=*last=t;
            (*head)->next=t;
            (*head)->prev=t;
        }
        else
        {
            
            (*last)->next=t;
            t->prev=*last;
            *last=t;
            (*last)->next=(*head);
            (*head)->prev=t;
        }
        
    }
}
void display(struct node *p)
{
    struct node *f=p;
    printf("\n");
    do
    {
        printf(" %d -> ",p->data);
        p=p->next;
    }while(p!=f);
}
int main()
{
    struct node *head,*last;
    int n;
    printf("Enter Size Of LL: ");
    scanf("%d",&n);
    create(&head,&last,n);
    display(head);
}