#include<stdio.h>
#include<stdlib.h>
struct queue
{
    int *data;
    int size;
    int front;
     int rear;
};
void enqueue(int x,struct queue *q)
{
    if((q->rear+1)%q->size==q->front)
    {
    printf("Overflow!!! \n");
    return;
    }
    else
    {
        q->rear=(q->rear+1)%q->size;
        q->data[q->rear]=x;
    }
}
int dequeue(struct queue *q)
{
    int x=-1;
    if(q->front==q->rear)
    {
    printf("Underflow ! \n");
    return x;
    }
    else
    {
        x=q->data[q->front];
        q->front=(q->front+1)%q->size;
        return x;
    }
}
void display(struct queue q)
{
    for(int i=q.front+1;i<=q.rear;i++)
    printf("%d ",q.data[i]);
    printf("\n\n");
}
void create(struct queue *q,int s)
{
    q->front=q->rear=0;
    q->size=s;
    q->data=(int *)malloc(q->size*sizeof(int));
}
int main()
{
    struct queue q;
    create(&q,10);
    enqueue(2,&q);
    enqueue(4,&q);
    enqueue(6,&q);
    enqueue(8,&q);
    display(q);
    dequeue(&q);
    dequeue(&q);
    display(q);
     enqueue(2,&q);
    enqueue(4,&q);
    enqueue(6,&q);
    enqueue(8,&q);
    dequeue(&q);
    dequeue(&q);
    display(q);
    return 0;
}