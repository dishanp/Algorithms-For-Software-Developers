//Q6- Compare 2 distances
#include <iostream>
using namespace std;
int c;
class distances
{
    int dist;

        public:

    void get()
        {
            cout<<"Enter Distance "<<++c<<"(in km) :  ";
            cin>>dist;
        }
    
    void show()
        {
            cout<<"Distance is : "<<dist;
        }
    void operator > (distances d2)
        {
            if(dist > d2.dist)
                {
                    cout<<"D1 is Greater"<<endl;
                }
            else if(dist < d2.dist )
                {
                    cout<<"D2 is greater"<<endl;
                }
        }
          void operator = (distances d2)
        {
            if(dist == d2.dist)
                {
                    cout<<"(D1 and D2 are equal)"<<endl;
                }
            else
                {
                    cout<<"(The distances are Not Equal)"<<endl;
                }
        }};

int main()
{
    distances d1, d2;
    d1.get();
    d2.get();
    d1 > d2;
    d1 = d2;
    return 0;
}