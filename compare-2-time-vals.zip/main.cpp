// Compare 2 time values
#include <iostream>
using namespace std;

class TIME
{
    int hr;
    int min;

        public:

    void get()
        {
            cout<<"Enter Hours:  ";
            cin>>hr;
            cout<<"Enter Minutes:  ";
            cin>>min;

            if(min > 59)
                    {
                        min -= 60;
                        hr += 1;
                    }
        }
    
    void show()
        {
            cout<<"Time is : "<<hr<<" : "<<min<<endl;
        }

    
    void operator + (TIME t2)
        {
            hr = hr + t2.hr;
            min = min + t2.min;

                if(min > 59)
                    {
                        min -= 60;
                        hr += 1;
                    }
        }
    
    void operator >  (TIME t2)
        {
            if(hr > t2.hr)
                {
                    cout<<"T1 is Greater"<<endl;
                }
            else if(hr == t2.hr  && min > t2.min)
                {
                    cout<<"T1 is greater"<<endl;
                }
            else if (hr < t2.hr)
                {
                    cout<<"T2 is greater"<<endl;
                }
            else if (hr == t2.hr  && min < t2.min)
                {
                    cout<<"T2 is greater"<<endl;
                }

        }

    void operator ==  (TIME t2)
        {
            if(hr == t2.hr && min == t2.min)
                {
                    cout<<"T1 and T2 are equal"<<endl;
                }
            else
                {
                    cout<<"T1 and T2 are Not Equal"<<endl;
                }
        }
    
    void operator = (TIME t2)
    {
        hr = t2.hr;
        min = t2.min;
    }
    
};

int main()
{
 TIME t1, t2;

    cout<<"Enter the Time 1: "<<endl;
    t1.get();
    cout<<"Enter the Time 2: "<<endl;
    t2.get();
    t1 > t2;
    t1 == t2;
    return 0;
}