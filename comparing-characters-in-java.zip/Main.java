
public class Main
{
	public static void main(String[] args) {
		char a='e';
		char b='s';
		if(a<b)
		System.out.println(a+" "+b);
		else
		System.out.println(b+" "+a);
	}
}
