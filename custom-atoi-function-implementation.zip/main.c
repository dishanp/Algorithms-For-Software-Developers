#include<stdlib.h>
#include <stdio.h>
int main()
{
    char ch[25];
    printf("ENTER STRING: ");
    scanf("%s",&ch);
    custom_atoi(ch);
    return 0;
}
void custom_atoi(char *str)
{
    int r;
    int res=0;
    for(int i=0;str[i]!='\0';i++)
    {
        r=str[i]-'0';
        res=(res*10)+r;
    }
    printf("%d",res);
}
