#include<iostream>
using namespace std;
#include<math.h>
class point
{
    int x;
    int y;
    int z;
    public:
    point()
    {
        x=y=z=0;
    }
    point(int a,int b,int c)
    {
        x=a;
        y=b;
        z=c;
    }
    point(point &obj)
    {
        x=obj.x;
        y=obj.y;
        z=obj.z;
    }
    friend float operator - (point,point);
};
 float operator - (point o,point a)
 {
     float dist;
     dist=sqrt((((a.x-o.x)*(a.x-o.x))+((a.y-o.y)*(a.y-o.y))+((a.z-o.z)*(a.z-o.z))));
     return dist;
 }
 
int main()
{
    point p1(1,2,3);
    point p2(4,5,6);
    cout<<(p1-p2);
    return 0;
}