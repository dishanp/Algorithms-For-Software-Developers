#include<iostream>
using namespace std;
template<class T>
T find(T *t,int i)
{
    T m=t[i];
    return m;
}
int main()
{
    //First for Integer Array:
    int a[5]={1,2,3,4,5};
    int n=sizeof(a)/sizeof(int);
    int i;
    try
    {
    cout<<"Enter Index To Be Searched Integer Array: ";
    cin>>i;
    if(i<0||i>=n)
    throw(i);
    }
    catch(int i)
    {
        cout<<"Entered Index "<<i<<" Is Invalid"<<endl;
        cout<<"Error Name: ARRAY OUT OF BOUNDS EXCEPTION \n";
        goto here;
    }
    cout<<"Element in Integer Array At Entered Index Is: "<<find(a,i)<<endl;
    here:
    //Now for float Array:
    float b[5]={1.1,2.2,3.3,4.4,5.5};
    n=sizeof(b)/sizeof(float);
    try
    {
    cout<<"Enter Index To Be Searched In float Array: ";
    cin>>i;
    if(i<0||i>=n)
    throw(i);
    }
    catch(int i)
    {
        cout<<"Entered Index "<<i<<" Is Invalid"<<endl;
        cout<<"Error Name: ARRAY OUT OF BOUNDS EXCEPTION \n";
        exit(0);
    }
    cout<<"Element in Float Array At Entered Index Is: "<<find(b,i)<<endl;
    return 0;
}
