#include <iostream>
using namespace std;
/*
1 foot = .3048meter = 12inches. 1inch = 2.54cm
*/
class Info2;
class Info1
{
int feet;
int inch;
public:
void get()
{
cout << "enter the distance (in feet and inches) : ";
cin >> feet >> inch;
}
void show()
{
cout << "Value Distance1 : \n " << feet << "feet " << inch << "inches" <<
endl;
}
friend void max(Info1 x1, Info2 x2);
};
class Info2
{
int m;
int cm;
public:
void get()
{
cout << "enter the distance (in meter and centimeter) : ";
cin >> m >> cm;
}
void show()
{
cout << "Value Distance2 : \n " << m << "m " << cm << "cm" << endl;
}
friend void max(Info1 x1, Info2 x2);
};
void max(Info1 x1, Info2 x2)
{
x1.feet = x1.feet * .3048;
x1.inch = x1.inch * 2.54;
if (x1.inch >= 12)
{
x1.feet += x1.inch / 12;
x1.inch = x1.inch / 12;
}
if (x2.cm >= 100)
{
x2.m += x2.cm / 100;
x2.cm = x2.cm / 100;
}
if (x1.feet > x2.m)
{
cout << "Distance 1 is greater" << endl;
}
else
cout << "Distance 2 is greater\n";
}
int main()
{
Info1 obj1;
Info2 obj2;
obj1.get();
obj2.get();
obj1.show();
obj2.show();
max(obj1, obj2);
return 0;
}