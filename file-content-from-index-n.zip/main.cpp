#include<iostream>
#include<fstream>
using namespace std;
#include<string.h>
int main()
{
    char str[100];
    ofstream fout;
    fout.open("DEMO.txt");
    cout<<"Enter content of file: "<<endl;
    gets(str);
    fout<<str<<endl;
    fout.close();
    cout<<"Enter value of n: ";
    int n;
    cin>>n;
    ifstream fin;
    fin.open("DEMO.txt");
    while(fin)
    {
    fin.getline(str,100);
    }
    for(int i=n;i<10;i++)
    {
        cout<<str[i];
    }
    fin.close();
    return 0;
}