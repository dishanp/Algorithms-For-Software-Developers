#include <iostream>
#include <fstream>
#include <string.h>
using namespace std;

void countwords()
{
    ifstream fin;
    fin.open("DataforWordCount.txt");
    char word[30];
    int count = 0;
    while (!fin.eof())
    {
        fin >> word;
        count++;
    }
    cout << "Number of words in file are " << count << endl;
    fin.close();
}
void countDigits()
{
    ifstream fin;
    fin.open("DataforWordCount.txt");
    int i, count = 0;
    char ch;
    while (!fin.eof())
    {
        fin.get(ch);
        i = ch;
        if (i > 47 && i < 58)
            count++;
    }
    cout << "Number of Digits in the file are : " << count << endl;
    fin.close();
}
void CountUpperNLowerCase()
{
    ifstream fin;
    fin.open("DataforWordCount.txt");
    int i, countU = 0, countL = 0;
    char ch;
    while (!fin.eof())
    {
        fin.get(ch);
        i = ch;
        if (i >= 65 && i <= 90)
            countU++;
        if (i >= 97 && i <= 122)
            countL++;
    }
    cout << "Number of Upper Case : " << countU << endl;
    cout << "Number of Lower Case : " << countL << endl;
    fin.close();
}
void countLines()
{
    ifstream in("DataforWordCount.txt");
    int i, count = 0;
    string str;
    while (getline(in, str))
    {
        count++;
    }
    cout << "Total Line Count : " << count << endl;
    in.close();
}
void countTotal()
{
    ifstream in("DataforWordCount.txt");
    int i, count = 0;
    char ch;
    while (!in.eof())
    {
        in.get(ch);
        i = ch;
        if (ch != ' ')
            count++;
    }
    cout << "Total Character Count : " << count << endl;
    in.close();
}
void SpecialCount()
{
    ifstream in("DataforWordCount.txt");
    int i, count = 0;
    char ch;
    while (!in.eof())
    {
        in.get(ch);
        i = ch;
        if (!((i >= 65 && i <= 90) || (i >= 97 && i <= 122) || (i > 47 && i < 58)))
            count++;
    }
    cout << "Total Special Symbols : " << count << endl;
    in.close();
}
int main()
{
    ofstream fout;
    fout.open("DataforWordCount.txt");
    char ch[25]="KiiT uniVersity 2020";
    fout<<ch;
    fout.close();
    cout << "Reading Data from file : DataforWordCount.txt...\n";
    int choice;
    cout << "Enter 1 to Count Total Characters\nEnter 2 to Count Words\nEnter 3 to Count Digits\nEnter 4 to Count Upper and Lower Case\nEnter 5 to Count Lines\nEnter 6 to count symbols\n";
    do
    {
        cout << "Enter Choice : ";
        cin >> choice;
        if (choice == 1)
        {
            countTotal();
        }
        else if (choice == 2)
        {
            countwords();
        }
        else if (choice == 3)
        {
            countDigits();
        }
        else if (choice == 4)
        {
            CountUpperNLowerCase();
        }
        else if (choice == 5)
        {
            countLines();
        }
        else if (choice == 6)
        {
            SpecialCount();
        }
        else
        {
            if (choice != 0)
                cout << "Invalid Choice\n";
            else
                break;
        }
    } while (choice != 0);
    return 0;
}