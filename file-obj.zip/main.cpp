//Q6 Copy Obj to file using read and write
#include <iostream>
#include <fstream>
 
using namespace std;
 
//class student to read and write student details
class student
{
    private:
        char name[30];
        int age;
    public:
        void getData(void)
        { cout<<"Enter name:"; cin.getline(name,30);
          cout<<"Enter age:"; cin>>age;
        }
 
        void showData(void)
        {
        cout<<"Name:"<<name<<",Age:"<<age<<endl;
        }
};
 
int main()
{
    student s;
     
    ofstream file;
 
    //open file in write mode
    file.open("aaa.txt",ios::out);
    if(!file)
    {
      cout<<"Error in creating file.."<<endl;
      return 0;
    }
    cout<<"\nFile created successfully."<<endl;
 
    //write into file
    s.getData();    //read from user
    file.write((char*)&s,sizeof(s));    //write into file
 
    file.close();   //close the file
    cout<<"\nFile saved and closed succesfully."<<endl;

    ifstream file1;
    //again open file in read mode
    file1.open("aaa.txt",ios::in);
    if(!file1){
        cout<<"Error in opening file..";
        return 0;
    }
    file1.read((char*)&s,sizeof(s));
 
   
    s.showData();
    //close the file
    file1.close();
     
    return 0;
}