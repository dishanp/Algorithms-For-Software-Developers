#include <iostream>
using namespace std;
#include<bits/stdc++.h>
int main()
{
    string s[5]={"IND","PAK","IND","CHI","CHIC"};
    unordered_map<string,int>h;
    for(int i=0;i<5;i++)
    {
        h[s[i]]++;
    }
    int max=-99999;
    string m="";
    for(auto i:h)
    {
        if(i.second>max)
        {
           max=i.second;
           m=i.first;
        } 
        
    }
    std::cout << m << std::endl;
    return 0;
}