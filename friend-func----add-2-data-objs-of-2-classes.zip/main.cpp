#include<iostream>
using namespace std;
class test1;
class test 
{
    int a;
    public:
    test()
    {
        a=5;
    }
    friend int sum(test,test1);
};
class test1
{
    int b;
    public:
    test1()
    {
       b=10; 
    }
    friend int sum(test,test1);
};
int sum(test obj,test1 obj1)
{
    cout<<obj1.b+obj.a;
}
int main()
{
    test t;
    test1 t1;
    sum(t,t1);
    return 0;
    
}
