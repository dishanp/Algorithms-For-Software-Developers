#include<iostream>
using namespace std;
float FUNAREA(float r)
{
    cout<<"Area of circle is: ";
    return 3.14*r*r;
}
float FUNAREA(float l,float b)
{
    cout<<"Area of rectangle is: ";
    return l*b;
}
float FUNAREA(float l,float b,float h)
{
    cout<<"volume of box is: ";
    return l*b*h;
}
float FUNAREA()
{
    cout<<"No parameter provided! "<<endl;
}
int main()
{
    cout<<FUNAREA(10)<<endl;
    cout<<FUNAREA(10,10)<<endl;
    cout<<FUNAREA(10,10,10)<<endl;
    FUNAREA();
}