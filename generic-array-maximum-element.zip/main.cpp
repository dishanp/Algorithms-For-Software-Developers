#include<iostream>
using namespace std;
template<class T>
T max(T *t,int n)
{
    T m=-99999;
    for(int i=0;i<n;i++)
    {
        if(t[i]>m)
        m=t[i];
    }
    return m;
}
int main()
{
    int a[5]={1,2,3,4,5};
    int n=sizeof(a)/sizeof(int);
    cout<<"Maximum Element in Integer Array Is: "<<max(a,n)<<endl;
    float b[5]={1.1,2.2,3.3,4.4,5.5};
    n=sizeof(b)/sizeof(int);
    cout<<"Maximum Element in Float Array Is: "<<max(b,n)<<endl;
    return 0;
}