import java.util.*;
class BlankCharacterException extends Exception
{
    public BlankCharacterException(String s)
    {
        super(s);
    }
}
class characters{
    String str;
    Scanner sc=new Scanner(System.in);
    public void input(){
        System.out.println("Enter The String: ");
        str=sc.nextLine();
    }
    public void show(){
        System.out.println(str);
    }
    public void operation(){
        try{

        char[] str1 = str.toCharArray();
        
        for(int i=0;i<str1.length;i++){
            if(str1[i]==' '){
                throw new BlankCharacterException("Invalid String!!!");
            }
            if(Character.isUpperCase(str1[i])){
                str1[i]+=32;
            }
            else if(Character.isLowerCase(str1[i])){
                str1[i]-=32;
            }
            
        } 
         str = new String(str1);
        }catch (BlankCharacterException ex)
        {
            System.out.println("Caught");
            System.out.println(ex.getMessage());
            System.exit(0);
        }
    }
}
public class Main
{
	public static void main(String[] args) {
		characters obj=new characters();
		obj.input();
		obj.show();
		obj.operation();
		obj.show();
	}
}
