//insertion sort
#include<stdio.h>
#include<stdlib.h>
void display(int *a,int n)
{
    printf("\nThe Array Is: \n");
    for(int i=0;i<n;i++)
    {
        printf("%d ",a[i]);
    }
}
void insertion(int *a,int n)
{
    int x,j;
    for(int i=1;i<n;i++)
    {
        x=a[i];
        j=i-1;
        while(j>=0&&x<a[j])
        {
            a[j+1]=a[j];
            j--;
        }
        a[j+1]=x;
    }
}
int main()
{
    int *a;
    int n;
    printf("Enter the size of the array: ");
    scanf("%d",&n);
    a=(int *)malloc(n*sizeof(int));
    for(int i=0;i<n;i++)
    {
        printf("\n Enter element %d: ",i+1);
        scanf("%d",&a[i]);
    }
    display(a,n);
    insertion(a,n);
    display(a,n);
}