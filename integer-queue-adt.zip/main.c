//Integer Queue ADT
#include<stdio.h>
#include<stdlib.h>
struct queue
{
   int *data;
   int front;
   int rear;
   int size;
};
void initialise(struct queue *q1)
{
    q1->front=q1->rear=-1;
    printf("Enter size of queue- \n");
    scanf("%d",&q1->size);
    q1->data=(int *)malloc(q1->size * sizeof(int)); 
}
void display(struct queue *q)
{
   
    for(int i=q->front;i<=q->rear;i++)
    {
        printf(" %d ",q->data[i]);
    }
    printf("\n");
}
void enqueue(struct queue *q,int x)
{
    if(q->rear==q->size-1)
    {
        printf("Queue Overflow!!! \n");
        return;
    }
    if(q->rear==q->front==-1)
    {
        q->rear=q->front=0;
        q->data[q->rear]=x;
    }
    else 
    {
        q->rear++;
        q->data[q->rear]=x;
    }
}
int dequeue(struct queue *q)
{
    int x=-1;
      if(q->front==-1||q->rear==-1)
    {
        printf("Queue Underflow !!! \n");
    } 
    
    {
       if(q->front==q->rear)
       {
           x=q->data[q->front];
           q->front=q->rear=-1;
       }
       else
       {
           x=q->data[q->front];
           q->front++;
       }
    }
    return x;
}
int main()
{
    struct queue q1;
    initialise(&q1);
    enqueue(&q1,2);
    enqueue(&q1,4);
    enqueue(&q1,6);
    enqueue(&q1,8);
    enqueue(&q1,10);
    display(&q1);
    dequeue(&q1);
    dequeue(&q1);
    dequeue(&q1);
    display(&q1);
    enqueue(&q1,10);
    display(&q1);
}