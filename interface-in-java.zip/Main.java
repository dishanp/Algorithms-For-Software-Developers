import java.util.*;
interface numbers{
    int x=0;
    int y=0;
    int process(int x,int y);
};
class sum implements numbers{
    public int process(int x,int y)
    {
        return x+y;
    }
};
class average implements numbers{
    public int process(int x,int y)
    {
        return (x+y)/2;
    }
}
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
		System.out.println("Enter x and y: ");
		int x,y;
		x=sc.nextInt();
		y=sc.nextInt();
		sum s=new sum();
		System.out.println("Sum is "+s.process(x,y));
		average a=new average();
		System.out.println("Average is "+a.process(x,y));
	}
}
