class BalException extends Exception
{
    public BalException(String s)
    {
        // Call constructor of parent Exception
        super(s);
    }
}
class acc{
    int bal;
    acc(int bal){
        try{
        this.bal=bal;
        if(bal<500)
        throw new BalException("Balance Too Low!");  
        }catch (BalException ex)
        {
            System.out.println("Caught");
            System.out.println(ex.getMessage());
        }
    }
    void deposit(int x)
    {
        bal+=x;
    }
    void withdraw(int x)
    {
        try{
        if(bal-x<500)
        throw new BalException("Balance Too Low!");
        else
        bal-=x;
        }catch (BalException ex)
        {
            System.out.println("Caught");
            System.out.println(ex.getMessage());
        }
    }
    void show()
    {
        System.out.println("Balance is "+bal);
    }
}
public class Main
{
	public static void main(String[] args) {
		acc a=new acc(100);
		a.deposit(200);
		a.withdraw(700);
		a.show();
	}
}
