public class Main
{
	public static void main(String[] args) {
		BankAccount obj1=new BankAccount();
		BankAccount obj2=new BankAccount();
		obj1.getv(10000,171,"Dishan");
		obj2.getv(12000,233,"ravi");
		obj1.dis();
		obj2.dis();
		obj2.with(200);
		obj1.dep(8999);
	}
}
class BankAccount
{
    int bal;
    String name;
    int acc_no;
    void getv(int b,int a,String n)
    {
        bal=b;
        acc_no=a;
        name=n;
    }
    void dis()
    {
       System.out.println(name);
       System.out.println(acc_no);
       System.out.println(bal);
    }
    void dep(int x)
    {
        bal+=x;
        System.out.println("Updated balance is "+bal);
    }
    void with(int y)
    {
        if(bal>=y)
        {
            bal-=y;
            System.out.println("Updated balance is "+bal);
        }
    }
}