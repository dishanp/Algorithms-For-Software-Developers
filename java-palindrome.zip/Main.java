import java.util.*;
public class Main
{
    static boolean check(int a)
    {
        int b=a;
        int rem,rev=0;
        while (b!=0)
        {
            rem=b%10;
            rev=(rev*10)+rem;
            b=b/10;
        }
        if(a==rev)
        return true; 
        else
        return false;
    }
	public static void main(String[] args) {
		System.out.println("Enter A No");
		int no;
		Scanner sc=new Scanner(System.in);
		no=sc.nextInt();
		if(check(no))
		System.out.println("Palindrome!");
		else
		System.out.println("Not Palindrome!");
	}
}
