import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your First Name: ");
		String Name=sc.nextLine();
		System.out.println("Enter Your Last Name: ");
		String lName=sc.nextLine();
		String wname=Name+" "+lName;
		System.out.println("Welcome Aboard "+wname);
		String sp[]=wname.split("\\s");
		for(int i=sp.length-1;i>=0;i--)
		System.out.println(sp[i]);
	}
}
