import java.util.*;
class HourException extends Exception
{
    public HourException(String s)
    {
        // Call constructor of parent Exception
        super(s);
    }
}
class MinException extends Exception
{
    public MinException(String s)
    {
        // Call constructor of parent Exception
        super(s);
    }
}
class SecException extends Exception
{
    public SecException(String s)
    {
        // Call constructor of parent Exception
        super(s);
    }
}
class time{
    int h,m,s;
    void get()
    {
        Scanner sc=new Scanner(System.in);
        try{
        System.out.println("Enter Hour,minute,second: ");
        h=sc.nextint();
        m=sc.nextint();
        s=sc.nextint();
        if(h>24||h<0)
        throw new HourException("Invalid Hours!");
        if(m>60||m<0)
        throw new MinException("Invalid Minutes!");
        if(s>60||s<0)
        throw new SecException("Invalid Seconds!");
        }
        catch (HourException ex)
        {
            System.out.println("Caught");
            System.out.println(ex.getMessage());
        }
        catch (MinException ex)
        {
            System.out.println("Caught");
            System.out.println(ex.getMessage());
        }
        catch (SecException ex)
        {
            System.out.println("Caught");
            System.out.println(ex.getMessage());
        }
        finally{
            System.out.println("Always Executer MF!");
        }
    }
    
}
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		time t=new time();
		t.get();
	}
}
