#include<stdio.h>
#include<stdlib.h>
struct node
{
    struct node *prev;
    int data;
    struct node *next;
};
void create(struct node **first,struct node **last,int n)
{
    struct node *temp;
    for(int i=0;i<n;i++)
    {
        temp=(struct node *)malloc(sizeof(struct node));
        printf("ENTER NODE %d- ",i+1);
        scanf("%d",&temp->data);
        temp->next=NULL;
        if(*first==NULL)
        {
            *first=*last=temp;
            (*first)->next=(*first)->prev=*first;
        }
        else
        {
            (*last)->next=temp;
            temp->prev=*last;
            *last=temp;
            (*last)->next=*first;
             (*first)->prev=*last;
        }
    }
}
void display(struct node *p,struct node *q)
{
    do
    {
        printf("%d -> ",p->data);
        p=p->next;
    }while(p!=q);
    printf("\n");
}
void join(struct node **first1,struct node **last1,struct node **first2,struct node **last2)
{
    (*last1)->next=*first2;
    (*first2)->prev=*last1;
    (*last2)->next=*first1;
    (*first1)->prev=*last2;
}
int main()
{
    struct node *first1=NULL;
    struct node *last1=NULL;
    printf("ENTER SIZE OF DCLL 1 = \n");
    int n;
    scanf("%d",&n);
    create(&first1,&last1,n);
    display(first1,first1);
    struct node *first2=NULL;
    struct node *last2=NULL;
    printf("ENTER SIZE OF DCLL 2 = \n");
    scanf("%d",&n);
    create(&first2,&last2,n);
    display(first2,first2);
    join(&first1,&last1,&first2,&last2);
    display(first1,first1);
}
