#include<stdio.h>
#include<stdlib.h>
struct node
{
    struct node *prev;
    int data;
    struct node *next;
};
void create(struct node **first,struct node **last,int n)
{
    struct node *temp;
    for(int i=0;i<n;i++)
    {
        temp=(struct node *)malloc(sizeof(struct node));
        printf("ENTER NODE %d- ",i+1);
        scanf("%d",&temp->data);
        temp->next=NULL;
        if(*first==NULL)
        {
            *first=*last=temp;
            (*first)->next=(*first)->prev=NULL;
        }
        else
        {
            (*last)->next=temp;
            temp->prev=*last;
            *last=temp;
            
        }
    }
}
void display(struct node *p)
{
    while(p)
    {
        printf("%d -> ",p->data);
        p=p->next;
    }
    printf("\n");
}
void sorted_insert(int el,struct node **p,struct node **r)
{
    struct node *q=*p;
    struct node *temp=(struct node *)malloc(sizeof(struct node));
    while(q)
    {
        if(el<q->data)
        {
           temp->data=el;
           temp->next=*p;
           (*p)->prev=temp;
           *p=temp;
            (*p)->prev=NULL;
           break;
        }
        else if(el>q->data && q->next==NULL)
        {
            temp->data=el;
            (*r)->next=temp;
            temp->prev=*r;
            temp->next=NULL;
            *r=temp;
            break;
        }
        else if(el>=q->data && el<=q->next->data)
        {
            temp->data=el;
            temp->next=q->next;
            q->next->prev=temp;
            q->next=temp;
            temp->prev=q;
            break;
        }
        
        else
        q=q->next;
        
    }
}
void check_palindrome(struct node *p,struct node *f1)
{
    struct node *q=NULL;
    struct node *r=NULL;
    while(p)
    {
        r=q;
        q=p;
        p=p->next;
        q->next=r;
    }    
    struct node *newf=q;
    int c=0;
     while(newf && f1)
    {
        if(newf->data!=f1->data)
        {
           printf("NOT PALINDROME !!! \n");
           c++;
           break;
        }
        newf=newf->next;
        f1=f1->next;
    }
    if(c==0) printf("PALINDROME! \n");
}
int main()
{
    struct node *first=NULL;
    struct node *last=NULL;
    printf("ENTER SIZE OF LL = \n");
    int n;
    scanf("%d",&n);
    create(&first,&last,n);
    display(first);
    check_palindrome(first,first);
    printf("Enter Element to be inserted in sorted manner - ");
    int x;
    scanf("%d",&x);
    sorted_insert(x,&first,&last);
    display(first);
}
