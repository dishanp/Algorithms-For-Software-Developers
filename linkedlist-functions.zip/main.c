#include<stdio.h>
#include<stdlib.h>
struct node
{
    struct node *prev;
    int data;
    struct node *next;
};
void create(struct node **first,struct node **last,int n)
{
    struct node *temp;
    for(int i=0;i<n;i++)
    {
        temp=(struct node *)malloc(sizeof(struct node));
        printf("ENTER NODE %d- ",i+1);
        scanf("%d",&temp->data);
        temp->next=NULL;
        if(*first==NULL)
        {
            *first=*last=temp;
            (*first)->next=(*first)->prev=NULL;
        }
        else
        {
            (*last)->next=temp;
            temp->prev=*last;
            *last=temp;
            
        }
    }
}
void display(struct node *p)
{
    while(p)
    {
        printf("%d -> ",p->data);
        p=p->next;
    }
    printf("\n");
}
void revdis(struct node *p)
{
    printf("LL in reverse is- \n");
    while(p->next)
    {
        p=p->next;
    }
    while(p)
    {
        printf("%d -> ",p->data);
        p=p->prev;
    }
    printf("\n");
}
void mid(struct node *p)
{
    struct node *q=p;
    while(p)
    {
        p=p->next;
        if(p)
        {
            p=p->next;
        }
        if(p)
        {
            q=q->next;
        }
    }
    printf("\n %d is the middle element ! \n",q->data);
}
 void recursive_display(struct node *p)
 {
     printf("%d -> ",p->data);
     if(p->next==NULL)
     return;
     recursive_display(p->next);
 }
 void recursive_reverse_display(struct node *p)
 {
     if(!p)
     return;
     recursive_reverse_display(p->next);
     printf("%d -> ",p->data);
 }
 int getpos(struct node *p,int el)
 { 
     int pos=1;
     while(p)
     {
         if(el==p->data)
         return pos;
         pos++;
         p=p->next;
     }
 }
 int delkey(struct node **first)//function to delete a given key passed as input
 {
     printf("ENTER KEY TO BE DELETED - \n");
     int key;
     scanf("%d",&key);
     struct node *q=*first;
     while(q)
     {
         if(q->data == key)
         {
             delete(*first,getpos(q,key));
         }
         q=q->next;
     }
     struct node *d=*first;
     display(d);
 }
int delete(struct node **p,int po) 
{
    struct node *r=*p;
    if(po==1)
    {
        struct node *q=*p;
        *p=(*p)->next;
        (*p)->prev=NULL;
        free(q);
    }
    else
    {
        for(int i=0;i<po-1;i++)
        {
            r=r->next;
        }
        if(r)
        {
            r->prev->next=r->next;
            r->next->prev=r->prev;
            free(r);
        }
    }
    struct node *d=*p;
    display(d);
  
}
void lasttofirst(struct node **p)
{
    struct node *q=*p;
    while(q->next!=NULL)
    {
        q=q->next;
    }
    struct node *l=q;
    q->prev->next=NULL;
    free(q);
    l->next=*p;
    l->prev=NULL;
    *p=l;
    struct node *d=*p;
    display(d);
}
void Kth_from_last(struct node *p,int k)
{
    while(p->next)
    {
        p=p->next;
    }
    int i=1;
    struct node *q;
    for(q=p;i<k;i++)
    {
        q=q->prev;
    }
    printf("%d ",q->data);
}
int main()
{
    struct node *first=NULL;
    struct node *last=NULL;
    printf("ENTER SIZE OF LL = \n");
    int n;
    scanf("%d",&n);
    create(&first,&last,n);
    display(first);
    printf("\n");
    recursive_display(first);
    printf("\n");
    recursive_reverse_display(first);
    printf("\n");
    revdis(first);
    printf("\n");
    mid(first);
    //delete(&first,3);
    //delkey(&first);
    lasttofirst(&first);
    printf("ENTER k VALUE FOR Kth value from the end \n");
    int k;
    scanf("%d",&k);
    Kth_from_last(first,k);
}

