#include<stdio.h>
#include<stdlib.h>
struct node
{
    struct node *prev;
    int data;
    struct node *next;
};
void create(struct node **first,struct node **last,int n)
{
    struct node *temp;
    for(int i=0;i<n;i++)
    {
        temp=(struct node *)malloc(sizeof(struct node));
        printf("ENTER NODE %d- ",i+1);
        scanf("%d",&temp->data);
        temp->next=NULL;
        if(*first==NULL)
        {
            *first=*last=temp;
            (*first)->next=(*first)->prev=NULL;
        }
        else
        {
            (*last)->next=temp;
            temp->prev=*last;
            *last=temp;
            (*last)->next=NULL;
        }
    }
}
void display(struct node *p)
{
    while(p)
    {
        printf("%d -> ",p->data);
        p=p->next;
    }
    printf("\n");
}
void swap(struct node **first,struct node **last)
{
    int d1,d2,a,b;
    struct node *p=*first;
    struct node *q=*first;
    printf("Enter 1st node data: ");
    scanf("%d",&d1);
    printf("Enter 2nd node data: ");
    scanf("%d",&d2);
    while(p->data!=d1)
    {
        p=p->next;
    }
    while(q->data!=d2)
    {
        q=q->next;
    }
    if(p==*first)
    {
       a=1;
    }
    if(q==*last)
    {
       b=1;
    }
    struct node *ptr=q->prev;
    q->next=p->next;
    p->next->prev=q;
    if(a==1)
    {
        *first=q;
        q->prev=NULL;
    }
    else
    {
        q->prev=p->prev;
        q->prev->next=q;
    }
    ptr->next=p;
    p->prev=ptr;
    if(b==1)
    {
        *last=q;
        q->next=NULL;
    }
    else
    {
        p->next=ptr->next;
        p->next->prev=p;
    }
}
int main()
{
    struct node *first=NULL;
    struct node *last=NULL;
    printf("ENTER SIZE OF LL = \n");
    int n;
    scanf("%d",&n);
    create(&first,&last,n);
    display(first);
    swap(&first,&last);
    display(first);
}


