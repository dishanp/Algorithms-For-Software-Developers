#include<iostream>
using namespace std;
#include<iomanip>
int main()
{
    float a=9.8645;
    cout<<setw(10)<<setprecision(2)<<a;
}