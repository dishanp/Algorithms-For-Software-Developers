
public class Main
{
	public static void main(String[] args) {
		int no=4548;
		int[] h = new int[9];
		int rem,ctr=0;
	    while(no!=0)
	    {
	        rem=no%10;
	        ++h[rem];
	        no/=10;
	    }
	    for(int i=0;i<9;i++)
	    {
	        if(h[i]!=0)
            ctr++;
	    }
	    System.out.println(ctr);
	}
}

