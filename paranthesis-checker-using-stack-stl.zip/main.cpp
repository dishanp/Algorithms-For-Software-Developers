#include<bits/stdc++.h>
using namespace std;
bool checkp(string str)
{
    stack<char>s;
    char x;
    for(int i=0;i<str.size();i++)
    {
        if(str[i]=='('||str[i]=='{'||str[i]=='[')
        {
            s.push(str[i]);
            continue;
        }
        if(s.empty())
        return false;
        if(str[i]==')')
        {
            x=s.top();
            s.pop();
            if(x=='['||x=='{')
            return false;
        }
        else if(str[i]=='}')
        {
            x=s.top();
            s.pop();
            if(x=='['||x=='(')
            return false;
        }
        else if(str[i]==']')
        {
            x=s.top();
            s.pop();
            if(x=='('||x=='{')
            return false;
        }
    }
    return s.empty();
}
int main()
{
    cout<<"Enter the expression: ";
    string str;
    cin>>str;
    if(checkp(str))
    cout<<"Balanced!";
    else
    cout<<"NOT Balanced!";
    return 0;
}
