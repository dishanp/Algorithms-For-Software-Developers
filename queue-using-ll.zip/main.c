#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
};
struct node *front=NULL;
struct node *rear=NULL;
void enqueue()
{
        struct node *p=(struct node *)malloc(sizeof(struct node));
        if(!p) //overflow!
        return;
        printf("Enter data of Element: ");
        scanf("%d",&p->data);
        p->next=NULL;
        if(rear==NULL)
        {
           front=rear=p;
        }
        else
        {
            rear->next=p;
            rear=p;
        }
}
int dequeue()
{
    int x=-1;
    if(!front)
    {
        printf("Queue Underflow! \n");
        return x;
    }
    struct node *p=front;
    x=front->data;
    printf("%d is deleted!\n",x);
    front=front->next;
    free(p);
    return x;
}
void create(int n)
{
    for(int i=0;i<n;i++)
    {
        enqueue();
    }
}
void display()
{
    printf("\n");
    struct node *p=front;
    while(p)
    {
        printf("%d ",p->data);
        p=p->next;
    }
    printf("\n");
}
int main()
{
    int n,ch;
    printf("Enter No Of Elements In Queue: ");
    scanf("%d",&n);
    create(n);
    while(1)
    {
    printf(" Press \n 1.To Enqueue \n 2.To Dequeue \n 3.To display \n 4.To exit \n");
    scanf("%d",&ch);
    switch(ch)
    {
        case 1:
     {  
        enqueue();
        break;
     }
     case 2:
     {
         dequeue();
         break;
     }
     case 3:
     {
         display();
         break;
     }
     case 4:
     {
         exit(0);
     }
     default:
     {
         printf("Invalid Input! \n");
     }
    }
    }
    return 0;
}
