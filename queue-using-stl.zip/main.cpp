using namespace std;
#include<bits/stdc++.h>
int main()
{
    queue <int> q;
    int ch,x;
    while(ch!=0)
    {
        cin>>ch;
        if(ch==1)
        {
            x=rand()%12;
            q.push(x);
        }
        else if(ch==2)
        {
            x=q.front();
            q.pop();
        }
        else if(ch==3)
        {
            queue<int> g = q;
    while (!g.empty()) {
        cout << '\t' << g.front();
        g.pop();
    }
    cout << '\n';
        }
    }
    

    return 0;
}
