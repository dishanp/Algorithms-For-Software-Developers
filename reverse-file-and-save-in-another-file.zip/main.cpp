#include<iostream>
using namespace std;
#include<fstream>
#include<string.h>
#include<stdio.h>
int main()
{
    char ch[100];
    ofstream fout;
    fout.open("SOURCE.TXT");
    cout<<"Enter The File contents: "<<endl;
    gets(ch);
    fout<<ch<<endl;
    fout.close();
    ifstream fin;
    fin.open("SOURCE.TXT");
    fout.open("DESTINATION.TXT");
    char c;
    while(fin)
    {
        fin.getline(ch,100);
        for(int i=strlen(ch)-1;i>=0;i--)
        fout<<ch[i];
    }
    fin.close();
    fout.close();
}