#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct stack
{
    char *data;
    int top;
    int size;
};
void push(struct stack *s,char ch)
{
    if(s->top==s->size-1)
    {
        printf("OVERFLOW ! \n");
        return ;
    }
    s->data[++s->top]=ch;
}
char pop(struct stack *s)
{
    if(s->top==-1)
    {
        printf("UNDERFLOW! \n");
        return ;
    }
    char ch=s->data[s->top];
    s->top--;
    return ch;
}
int main()
{
    char sen[100]="({})";
    struct stack s;
    s.top=-1;
    s.size=strlen(sen);
    s.data=(char *)malloc(s.size * sizeof(char));
    for(int i=0;sen[i]!='\0';i++)
    {
        if(sen[i]=='('||sen[i]=='{'||sen[i]=='[')
        push(&s,sen[i]);
        else if(sen[i]==')'||sen[i]=='}'||sen[i]==']')
        pop(&s);
    }
    if(s.top==-1)
    {
        printf("EXPRESSION IS BALANCED \n");
    }
    else
    {
      printf("EXPRESSION IS NOT BALANCED \n");
    }
     
    return 0;
}
    

