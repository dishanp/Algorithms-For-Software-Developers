#include<bits/stdc++.h>
using namespace std;

int main()
{
    stack <char > s;
    cout<<"Enter the string: ";
    string str;
    cin>>str;
    for(int i=0;i<str.size();i++)
    {
        s.push(str[i]);
    }
    while(!s.empty())
    {
        cout<<s.top();
        s.pop();
    }
    return 0;
}
