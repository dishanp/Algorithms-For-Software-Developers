#include<stdio.h>
#include<stdlib.h>
struct queue
{
    char gen;
    struct queue *next;
};
void insert(struct queue **t,struct queue **first,struct queue **last)
{
    struct queue *temp=(struct queue *)malloc(sizeof(struct queue)); //just to check memory availability
    if(!temp)
  {  
    printf("OVERFLOW ! \n");
    return ; 
  }
    (*t)->next=NULL;
    if(*first==NULL)
        *first=*last=*t;
    else
    {
          (*last)->next=*t;
          *last=*t;
    }
}
void create(struct queue **first,struct queue **last)
{
    int n;
    printf("Enter the no of customers--- \n");
    scanf("%d",&n);
    struct queue *t=NULL;
    for(int i=0;i<n;i++)
    {
        t=(struct queue *)malloc(sizeof(struct queue));
        printf("ENTER GENDER OF CUSTOMER: \n");
        scanf("%c",&t->gen);
        insert(&t,first,last);
        free(t);
    }
}

void display(struct queue *p)
{
    while(p)
    {
        printf(" %c -> ",p->gen);
        p=p->next;
    }
    printf(" \n ");
}
void segregate(struct queue *p,struct queue **m_first,struct queue **m_last,struct queue **f_first,struct queue **f_last)
{
    while(p)
    {
        struct queue *t=p;
        if(p->gen=='M'||p->gen=='m')
        {
            insert(&t,m_first,m_last);
        }
         else if(p->gen=='F'||p->gen=='f')
        {
            insert(&t,f_first,f_last);
        }
        p=p->next;
    }
}
int main()
{
    struct queue *u_first=NULL; //unisex queue 
    struct queue *u_last=NULL;
    struct queue *m_first=NULL; //male queue
    struct queue *m_last=NULL;
     struct queue *f_first=NULL; //female queue
    struct queue *f_last=NULL;
    create(&u_first,&u_last);
    printf("UNISEX QUEUE = \n");
    display(u_first);
    segregate(u_first,&m_first,&m_last,&f_first,&f_last);
    printf(" MALE QUEUE - \n");
    display(m_first);
    printf(" FEMALE QUEUE - \n");
    display(f_first);
    return 0;
}

