//selection sort
#include<stdio.h>
#include<stdlib.h>
void display(int *a,int n)
{
    printf("\nThe Array Is: \n");
    for(int i=0;i<n;i++)
    {
        printf("%d ",a[i]);
    }
}
void selection(int *a,int n)
{
    int min,temp;
    for(int i=0;i<n-1;i++)
    {
        min=i;
        for(int j=i+1;j<n;j++)
        {
            if(a[min]>a[j])
            {
                min=j;
            }
        }
        temp=a[min];
        a[min]=a[i];
        a[i]=temp;
    }
}
int main()
{
    int *a;
    int n;
    printf("Enter the size of the array: ");
    scanf("%d",&n);
    a=(int *)malloc(n*sizeof(int));
    for(int i=0;i<n;i++)
    {
        printf("\n Enter element %d: ",i+1);
        scanf("%d",&a[i]);
    }
    display(a,n);
    selection(a,n);
    display(a,n);
    
}

