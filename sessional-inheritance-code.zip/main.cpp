#include<iostream>
using namespace std;
#include<stdio.h>
#include<string.h>
class student
{
    int rno;
    char branch[25];
    public:
    student(int a,char *ch)
    {
        rno=a;
        strcpy(branch,ch);
    }
};
class internal:public student
{
    int mark1[5];
    public:
    int sum1;
    internal(int *a)
    {   sum1=0;
        for(int i=0;i<5;i++)
      {  
        mark1[i]=a[i];
        sum1+=a[i]; 
          
      }
    }
};
class semester:public student
{
    int mark2[5];
    public:
    int s2;
    semester(int *a)
    {   s2=0
        for(int i=0;i<5,i++)
        {
        mark2[i]=a[i];
        s2+=a[i];
            
        }
    }
};
class result:public internal,public semester
{
    int total;
    public:
    void grade()
    {
        total=sum1+s2;
        cout<<"Total Marks="<<total;
    }
};
int main()
{
    result r;
    
}
