#include<iostream>
using namespace std;
class shape
{
    public:
    int r;
    int a;
    virtual void show()
    {
        cout<<"Base called \n";
    }
};
class circle:public shape
{
    public:
    void show()
    {
        cout<<"Enter Radius Of Circle"<<endl;
        cin>>r;
        cout<<3.14*r*r<<endl;
    }
};
class square:public shape
{
    public:
    void show()
    {
        cout<<"Enter Side length of square "<<endl;
        cin>>a;
        cout<<a*a<<endl;;
    }
};
int main()
{
    shape *s;
    circle c;
    square sq;
    s=&c;
    s->show();
    s=&sq;
    s->show();
}