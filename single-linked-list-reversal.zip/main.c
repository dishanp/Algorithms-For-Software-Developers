#include<stdio.h>
#include<stdlib.h>
struct node
{
    struct node *prev;
    int data;
    struct node *next;
};
void create(struct node **first,struct node **last,int n)
{
    struct node *temp;
    for(int i=0;i<n;i++)
    {
        temp=(struct node *)malloc(sizeof(struct node));
        printf("ENTER NODE %d- ",i+1);
        scanf("%d",&temp->data);
        temp->next=NULL;
        if(*first==NULL)
        {
            *first=*last=temp;
            (*first)->next=(*first)->prev=NULL;
        }
        else
        {
            (*last)->next=temp;
            temp->prev=*last;
            *last=temp;
            
        }
    }
}
void display(struct node *p)
{
    while(p)
    {
        printf("%d -> ",p->data);
        p=p->next;
    }
    printf("\n");
}
void reverse(struct node **head)
{
    struct node *r=NULL;
    struct node *q=NULL;
    struct node *p=*head;
    while(p)
    {
        r=q;
        q=p;
        p=p->next;
        q->next=r;
    }
    *head=q;
}
int main()
{
    struct node *first=NULL;
    struct node *last=NULL;
    printf("ENTER SIZE OF LL = \n");
    int n;
    scanf("%d",&n);
    create(&first,&last,n);
    display(first);
    printf("\n");
    reverse(&first);
    printf("After Reversing Linked List:\n");
    display(first);
    printf("\n");
}


