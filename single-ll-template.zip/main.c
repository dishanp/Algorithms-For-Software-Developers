#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
};
void create(struct node **head,struct node **last,int n)
{
    int el;
    struct node *t=NULL;
    for(int i=0;i<n;i++)
    {
        t=(struct node *)malloc(sizeof(struct node));
        printf("\n Enter Data No %d:",i+1);
        scanf("%d",&t->data);
        t->next=NULL;
        if(i==0)
        {
            *head=*last=t;
        }
        else
        {
            (*last)->next=t;
            *last=t;
        }
        
    }
}
void display(struct node *p)
{
    printf("\n");
    while(p)
    {
        printf(" %d -> ",p->data);
        p=p->next;
    }
}
int main()
{
    struct node *head,*last;
    int n;
    printf("Enter Size Of LL: ");
    scanf("%d",&n);
    create(&head,&last,n);
    display(head);
}