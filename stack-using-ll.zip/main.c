#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
};
struct stack 
{
    struct node **top;
    int size;
};
struct node *top=NULL;
void push()
{
        struct node *p=(struct node *)malloc(sizeof(struct node));
        if(!p) //overflow!
        return;
        printf("Enter data of Element: ");
        scanf("%d",&p->data);
        p->next=NULL;
        p->next=top;
        top=p;
}
int pop()
{
    int x=-1;
    if(!top)
    {
        printf("Stack Underflow! \n");
        return x;
    }
    struct node *p=top;
    x=top->data;
    printf("%d is deleted!\n",x);
    top=top->next;
    free(p);
    return x;
}
void create(int n)
{
    for(int i=0;i<n;i++)
    {
        push();
    }
}
void display()
{
    printf("\n");
    struct node *p=top;
    while(p)
    {
        printf("%d \n",p->data);
        p=p->next;
    }
    printf("\n");
}
int main()
{
    int n,ch;
    printf("Enter No Of Elements In Stack: ");
    scanf("%d",&n);
    create(n);
    while(1)
    {
    printf(" Press \n 1.To Push \n 2.To Pop \n 3.To display \n 4.To exit \n");
    scanf("%d",&ch);
    switch(ch)
    {
        case 1:
     {  
        push();
        break;
     }
     case 2:
     {
         pop();
         break;
     }
     case 3:
     {
         display();
         break;
     }
     case 4:
     {
         exit(0);
     }
     default:
     {
         printf("Invalid Input! \n");
     }
    }
    }
    return 0;
}