// Q4 - string concatentation 
#include <iostream>
using namespace std;
#include<stdio.h>
#include<string.h>
int c;
class Conc
{
    char *str1;
    public:
        Conc()
        {
            str1=new char[25];
        }
        void get()
        {
            cout<<"Enter String "<<++c<<":";
            cin>>str1;
        }
        void show()
       {
        puts(str1);
        cout<<endl;
        }
        Conc operator +(Conc &b)
    {
        Conc o;
        strcpy(o.str1,str1);
        strcat(o.str1,b.str1);
        return o;
    }
};
int main()
{
    Conc c,b,a;
    c.get();
    b.get();
    a=c+b;
    cout<<"Concatenated String: ";
    a.show();
    return 0;
}
