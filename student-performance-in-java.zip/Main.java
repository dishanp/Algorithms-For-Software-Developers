import java.util.*;
class Main{
    int rno;
    String name="";
    int marks[]=new int[3];
    Scanner sc=new Scanner(System.in);
    public void getdata(){
        System.out.println("Enter Name,Sec And Marks: ");
        name=sc.next();
        rno=sc.nextInt();
        for(int i=0;i<3;i++)
        {
            System.out.println("Enter Marks Of Subject "+(i+1)+": ");
            marks[i]=sc.nextInt();
        }
    }
    public int total(){
        int sum=0;
        for(int i=0;i<3;i++)
        {
            sum+=marks[i];
        }
        return sum;
    }
     public int average(){
        int sum=0;
        for(int i=0;i<3;i++)
        {
            sum+=marks[i];
        }
        return (sum/3);
    }
     public void showdata(){
        System.out.println(name);
        System.out.println(rno);
        for(int i=0;i<3;i++)
        {
            System.out.println("Marks Of Subject "+(i+1)+": "+marks[i]);
        }
    }
	public static void main(String[] args) {
		Main obj[]= new Main[3];
		for(int i=0;i<3;i++){
		    obj[i].getdata();
		    System.out.println("Sum: "+ obj[i].total());
		    System.out.println("Average: "+ obj[i].average());
		    obj[i].showdata();
		}
	}
}