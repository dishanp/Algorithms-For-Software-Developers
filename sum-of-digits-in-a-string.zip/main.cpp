using namespace std;
#include<bits/stdc++.h>
#include <stdio.h>
int main()
{
    printf("Enter The String: ");
    string str;
    cin>>str;
    int sum=0;
    for(int i=0;i<str.size();i++){
        char ch=str[i];
        if(ch>=48&& ch<=57){
            sum+=(int)ch-48;
        }
    }
    std::cout << sum << std::endl;
    return 0;
}
