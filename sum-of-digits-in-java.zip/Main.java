public class Main
{
	public static void main(String[] args) {
	    int n=1235;
	    int s=0;
	    int rem;
	    while(n>0)
	    {
	        rem=n%10;
	        s+=rem;
	        n=n/10;
	    }
		System.out.println("Sum Of Digits: "+s);
	}
}
