#include <iostream>
using namespace std;
class B;
class A
{
int x;
public:
void set(int t)
{
x=t;
}
void show()
{
cout <<"value of x is : "<< x << endl;
}
friend void swap(A *, B *);
};
class B
{
int y;
public:
void set(int w)
{
y = w;
}
void show()
{
cout <<"value of y is : "<< y << endl;
}
friend void swap(A *, B *);
};
void swap(class A *c, class B *d)
{
int temp;
temp = c->x;
c->x = d->y;
d->y = temp;
}
int main()
{
A n;
B m;
int a, b;
cout <<"ENTER THE VALUE OF X=";
cin >> a;
cout <<"ENTER THE VALUE OF Y=";
cin >> b;
n.set(a);
m.set(b);
swap(&n, &m);
n.show();
m.show();
return 0;
}