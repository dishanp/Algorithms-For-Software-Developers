#include<iostream>
using namespace std;
class test1;
class test 
{
    int a;
    public:
    test()
    {
        a=5;
    }
    friend int swap(test &,test1 &);
    void show()
    {
        cout<<a<<endl;
    }
};
class test1
{
    int b;
    public:
    test1()
    {
       b=10; 
    }
    void show()
    {
        cout<<b;
    }
    friend int swap(test &,test1 &);
};
int swap(test &obj,test1 &obj1)
{
    int temp=obj.a;
    obj.a=obj1.b;
    obj1.b=temp;
}
int main()
{
    test t;
    test1 t1;
    swap(t,t1);
    t.show();
    t1.show();
    return 0;
    
}
