#include <iostream>
using namespace std;

template<class T>

class Pair {
	T a[5], b[5];
public:

	Pair(){
		cout << "Enter 5 elements into first array:\n";
		for(int i = 0; i < 5; i++) cin >> a[i];
		cout << "Enter 5 elements into second array:\n";
		for(int i = 0; i < 5; i++) cin >> b[i];
	}

	void display(){
		maxOfFirstArray(a);
		secondMaxOfSecondArray(b);
		sumOfTwoArray(a, b);
		swapOfTwoArray(a, b);
	}
	
	void maxOfFirstArray(T arr[]){
		T max = arr[0];
		for (int i = 0; i < 5; ++i)
		{
			if (arr[i] > max) max = arr[i];
		}

		cout << "Max of First Array: " << max << endl;
	}

	void secondMaxOfSecondArray(T arr[]){
		T max = arr[0];
		T max2 = arr[0];
		for (int i = 0; i < 5; ++i)
		{
			if (arr[i] > max) max = arr[i];
		}

		for (int i = 0; i < 5; ++i)
		{
			if (arr[i] > max2 && arr[i] < max) max2 = arr[i];
		}

		cout << "Second Largest of second array: " << max2 << endl;
	}

	void sumOfTwoArray(T a[], T b[]){
		T arr[5];
		for (int i = 0; i < 5; ++i)
		{
			arr[i] = a[i] + b[i];
		}

		cout << "Printing Sum: ";
		for (int i = 0; i < 5; ++i)
		{
			cout << arr[i] << "\t";
		}
		cout << endl;
	}

	void swapOfTwoArray(T a[], T b[]){
		cout << "First Array: ";
		for (int i = 0; i < 5; ++i)
		{
			cout << a[i] << "\t";
		}
		cout << "\nSecond Array: ";
		for (int i = 0; i < 5; ++i)
		{
			cout << b[i] << "\t";
		}
		cout << "\n";

		for (int i = 0; i < 5; ++i)
		{
			a[i] = a[i] + b[i];
			b[i] = a[i] - b[i];
			a[i] = a[i] - b[i];
		}

		cout << "\nAfter Swap\nFirst Array: ";
		for (int i = 0; i < 5; ++i)
		{
			cout << a[i] << "\t";
		}
		cout << "\nSecond Array: ";
		for (int i = 0; i < 5; ++i)
		{
			cout << b[i] << "\t";
		}
		cout << "\n";
		
	}
};

int main()
{
	Pair<int> obj;
	obj.display();

}