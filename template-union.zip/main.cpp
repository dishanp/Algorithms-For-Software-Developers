#include<iostream>
using namespace std;
template<class T>
T * merge(T *t,T *t1,int n1,int n2)
{
    T m[n1+n2];   
    for(int i=0;i<n1;i++)
    {
        m[i]=t[i];
    }
    
    for(int j=0;j<n2;j++)
    {
        m[i]=t1[j];
        ++i;
    }
    return m;
}
int main()
{
    int a[5]={1,2,3,4,5};
    int n1=sizeof(a)/sizeof(int);
    int b[5]={1,2,3,4,5};
    int n2=sizeof(b)/sizeof(int);
    int c[10]=merge(a,b,n1,n2);
    for(int i=0;i<10;i++)
    cout<<c[i]<<" ";
    return 0;
}

