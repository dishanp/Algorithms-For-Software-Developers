#include<stdio.h>
#include<stdlib.h>
int sumLeaf;
struct tree
{
    struct tree *left;
    char data;
    struct tree *right;
};
struct queue
{
    int front;
    int rear;
    int size;
    struct tree **data;
};
int c=1;
struct tree *root;
void createQ(struct queue *q,int s)
{
    q->front=q->rear=0;
    q->size=s;
    q->data=(struct tree **)malloc(q->size*sizeof(struct tree *));
}
void enqueue(struct queue *q,struct tree *t)
{
    if((q->rear+1)%q->size==q->front)
    printf("Overflow ! \n");
    else
    {
        q->rear=(q->rear+1)%q->size;
        q->data[q->rear]=t;
    }
}
struct tree * dequeue(struct queue *q)
{
    struct tree *t=NULL;
    if(q->front==q->rear)
    printf("Queue Underflow! \n");
    else
    {
        q->front=(q->front+1)%q->size;
        t=q->data[q->front];
    }
    return t;
}
int isEmpty(struct queue q)
{
   return q.front==q.rear ;
}
void createT()
{
   struct tree *p,*t; 
   struct queue q;
   createQ(&q,100);
   int x;
   printf("Enter the root data value = ");
   scanf("%d",&x);
   root=( struct tree *)malloc(sizeof(struct tree));
   root->data=x;
   root->left=root->right=NULL;
   enqueue(&q,root);
   while(!isEmpty(q))
   {
       p=dequeue(&q);
       printf("Enter Left Child OF %d:- ",p->data);
       scanf("%d",&x);
       if(x!=-1)
       {
           t=( struct tree *)malloc(sizeof(struct tree));
           t->data=x;
           t->left=t->right=NULL;
           p->left=t;
           enqueue(&q,t);
       }
       printf("Enter Right Child OF %d:- ",p->data);
       scanf("%d",&x);
       if(x!=-1)
       {
           t=( struct tree *)malloc(sizeof(struct tree));
           t->data=x;
           t->left=t->right=NULL;
           p->right=t;
           enqueue(&q,t);
       }
   }
}
int sum(struct tree *t)
{
    if(!t)
    return 0;
    else
    return t->data + sum(t->left) + sum(t->right);
}
int isLeaf(struct tree *t)
{
    
    if(t && t->left==NULL && t->right==NULL)
    return 1;
    else
    return 0;
}
int sumLeafN(struct tree *t)
{
    if(isLeaf(t))
    sumLeaf+=t->data;
}
void preorder(struct tree *p)
{
    if(p)
    {
        printf("%d ",p->data);
        preorder(p->left);
        preorder(p->right);
    }
}
void inorder(struct tree *p)
{
    if(p)
    {
        inorder(p->left);
        sumLeafN(p);
        printf("%d ",p->data);
        inorder(p->right);
    }
}
int height(struct tree *t)
{
    if(!t)
    return 0;
    int x=height(t->left);
    int y=height(t->right);
    if(x>y)
    return x+1;
    else
    return y+1;
}
int count(struct tree *t)
{
    if(!t)
    return 0;
    return (count(t->left)+count(t->right)+1);
}
int count_Leaf(struct tree *t)
{
    if(!t)
    return 0;
    if (t->left==NULL && t->right==NULL)
    return 1;
    else
    return (count(t->left)+count(t->right));
}
int main()
{
   createT();
   inorder(root);
   printf("\nNo of nodes in tree: %d",count(root));
   printf("\nNo of Leaf nodes in tree: %d",count_Leaf(root));
   printf("\n");
   printf("Height Of Tree is: %d",height(root)-1);
   printf("\nSum Of All Node Is: %d",sum(root));
   printf("\nSum of Leaf Nodes Is: %d ",sumLeaf);
}

