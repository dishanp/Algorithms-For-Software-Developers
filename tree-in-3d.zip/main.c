#include<stdio.h>
#include<stdlib.h>
int count=10;
struct tree
{
    struct tree *left;
    char data;
    struct tree *right;
};
struct queue
{
    int front;
    int rear;
    int size;
    struct tree **data;
};

struct tree *root;
void createQ(struct queue *q,int s)
{
    q->front=q->rear=0;
    q->size=s;
    q->data=(struct tree **)malloc(q->size*sizeof(struct tree *));
}
void enqueue(struct queue *q,struct tree *t)
{
    if((q->rear+1)%q->size==q->front)
    printf("Overflow ! \n");
    else
    {
        q->rear=(q->rear+1)%q->size;
        q->data[q->rear]=t;
    }
}
struct tree * dequeue(struct queue *q)
{
    struct tree *t=NULL;
    if(q->front==q->rear)
    printf("Queue Underflow! \n");
    else
    {
        q->front=(q->front+1)%q->size;
        t=q->data[q->front];
    }
    return t;
}
int isEmpty(struct queue q)
{
   return q.front==q.rear ;
}
void createT()
{
   struct tree *p,*t; 
   struct queue q;
   createQ(&q,100);
   int x;
   printf("Enter the root data value = ");
   scanf("%d",&x);
   root=( struct tree *)malloc(sizeof(struct tree));
   root->data=x;
   root->left=root->right=NULL;
   enqueue(&q,root);
   while(!isEmpty(q))
   {
       p=dequeue(&q);
       printf("Enter Left Child OF %d:- ",p->data);
       scanf("%d",&x);
       if(x!=-1)
       {
           t=( struct tree *)malloc(sizeof(struct tree));
           t->data=x;
           t->left=t->right=NULL;
           p->left=t;
           enqueue(&q,t);
       }
       printf("Enter Right Child OF %d:- ",p->data);
       scanf("%d",&x);
       if(x!=-1)
       {
           t=( struct tree *)malloc(sizeof(struct tree));
           t->data=x;
           t->left=t->right=NULL;
           p->right=t;
           enqueue(&q,t);
       }
   }
}
void print2D(struct tree *root,int space)
{
    if(root==NULL)
    return;
    space+=count;
    print2D(root->right,space);
    printf("\n");
    for(int i=count;i<space;i++)
    {
        printf(" ");
    }
    printf("%d\n",root->data);
    print2D(root->left,space);
}
void preorder(struct tree *p)
{
    if(p)
    {
        printf("%d ",p->data);
        preorder(p->left);
        preorder(p->right);
    }
}
int main()
{
   createT();
   preorder(root);
   printf("\n");
   print2D(root,0);
}