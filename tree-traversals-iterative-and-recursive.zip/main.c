#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
    int data;
    struct node* left;
    struct node* right;
} node;

typedef struct tree
{
    node* data;
    struct tree* next;
} tree;

tree* Stack ;
tree* StackA;

void push(tree** top, node* d)
{
    tree* temp = (tree*)malloc(sizeof(tree));
    temp -> data = d;
    temp -> next = (*top);
    (*top) = temp;
}

node* pop(tree** top)
{
    if((*top) != NULL)
    {
        node* d = (*top)->data;
        tree* temp = (*top);
        (*top) = (*top)->next;

        free(temp);
        return d;
    }
}

node* createnode ( int d )
{
    node* temp = (node*)malloc(sizeof(node));
    temp->left = NULL;
    temp->right = NULL;
    temp->data = d;
    return temp;
}

void inorder ( node* t )
{

    if ( t != NULL )
    {
        inorder(t->left);
        printf("%d ",t->data);
        inorder(t->right);
    }
}

void postorder ( node* t )
{

    if ( t != NULL )
    {
        postorder(t->left);

        postorder(t->right);
        printf("%d ",t->data);
    }
}

void preorder ( node* t )
{

    if ( t != NULL )
    {
        printf("%d ",t->data);
        preorder(t->left);
        preorder(t->right);
    }
}

void inorderiter ( node* root )
{
    node* curr = root;

    while( curr != NULL || Stack != NULL )
    {
        while( curr != NULL )
        {
            push(&Stack,curr);
            curr = curr->left;
        }

        curr = pop(&Stack);
        printf("%d ",curr->data);
        curr = curr->right;
    }

    free (Stack);

}

void postorderiter ( node* root )
{
    if ( root != NULL )
    {
        push(&Stack,root);
        node* temp;

        while( Stack != NULL )
        {
            temp = pop(&Stack);
            push(&StackA,temp);

            if (temp->left)
                push(&Stack, temp->left);
            if (temp->right)
                push(&Stack, temp->right);
        }

        while (StackA != NULL)
        {
            temp = pop(&StackA);
            printf("%d ", temp->data);
        }
    }
}

void preorderiter ( node* root )
{
    if ( root == NULL )
        return;

    push(&Stack,root);

    while( Stack != NULL )
    {
        node *temp = pop(&Stack);
        printf("%d ",temp->data);

        if ( temp->right )
            push(&Stack,temp->right);

        if ( temp->left )
            push(&Stack,temp->left);
    }

    free (Stack);
}   

int main()
{
    Stack = NULL;

    node* root = createnode(1);
    root->left = createnode(2);
    root->right = createnode(3);

    root->left->left   = createnode(4);
    root->left->right  = createnode(5);
    root->right->left  = createnode(6);
    root->right->right = createnode(7);
    int ch;

    printf("Enter 1 for Preorder\nEnter 2 for Preorder\nEnter 3 for Postorder\n");
    printf("Enter Choice:  ");
    scanf("%d",&ch);

    switch (ch)
    {
    case 1:
            printf("\nInorder Using Recusrion: ");
            inorder(root);
            printf("\nInorder Using Iteration: ");
            inorderiter(root);
        break;
    
    case 2:
            printf("\nPreorder Using Recusrion: ");
            preorder(root);
            printf("\nPreorder Using Iteration: ");
            preorderiter(root);
        break;
    
    case 3:
            printf("\nPostorder Using Recusrion: ");
            postorder(root);
            printf("\nPostorder Using Iteration: ");
            postorderiter(root);
        break;
    
    default:
        break;
    }

}