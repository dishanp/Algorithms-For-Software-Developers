using namespace std;
#include<bits/stdc++.h>
#include<algorithm>
void display(vector<int>a){
    cout<<endl;
    for(int i=0;i<a.size();i++){
        cout<<a[i]<<" ";
    }
    cout<<endl;
}
vector<int> init(int n)
{
    vector<int>ar;
    for(int i=0;i<n;i++){
        ar.push_back(rand()%25);
    }
    return ar;
}
void sum_k(vector<int>a,int k){
    int i=0;
    int j=a.size()-1;
    while(i<j){
        if(a[i]+a[j]<k){
            i++;
        }
        else if(a[i]+a[j]>k){
            --j;
        }
        else{
            cout<<a[i]<<"+"<<a[j]<<"="<<k<<endl;
            i++;
            j--;
        }
        
    }
}
void rev(vector<int>a){
    int i=0;
    int j=a.size()-1;
    int temp;
    while(i<j)
    {
        temp=a[i];
        a[i]=a[j];
        a[j]=temp;
        i++;
        j--;
    }
    display(a);
}
int mid(vector<int>a){
    int n=a.size();
    if(n%2==0)
    return a[n/2];
    return a[(n+1)/2];
}
int main()
{
    vector<int>a=init(7);
    int n=a.size();
    display(a);
    sort(a.begin(),a.end());
    display(a);
    rev(a);
    sum_k(a,33);
    cout<<mid(a);
    return 0;
}
